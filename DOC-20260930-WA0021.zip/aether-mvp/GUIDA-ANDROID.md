# 🤖 Guida Android — costruire e installare Aether

Tre strade, dalla più facile alla più professionale. Tutte partono dalla cartella `aether-mvp`.

---

## Via 1 — Senza computer (GitHub Actions genera l'APK per te)

L'apk viene compilato nel cloud, gratis.

1. Crea un account gratuito su [github.com](https://github.com) (se non ce l'hai).
2. Crea un repository **privato** nuovo (es. `aether`).
3. Carica tutti i file di questa cartella nel repository (interfaccia web: "uploading an existing folder", o GitHub Desktop).
4. Nel repository apri la scheda **Actions**: troverai il workflow "Build APK Android" già pronto (`.github/workflows/android-apk.yml`) che parte da solo.
5. Quando la run diventa verde (~10-15 minuti), cliccala → in basso scarica l'artifact **aether-apk** (contiene il file `.apk`).
6. Sul telefono Android:
   - apri il file APK scaricato;
   - consenti "Installa app sconosciute" per il browser/file manager quando richiesto;
   - installala e apri Aether.
7. In **Impostazioni** verifica che Gemini sia attivo (la chiave è già inserita) → vai in **Chat** e scrivi.

> Nota: la chiave Gemini attualmente nel codice è quella incollata in chat — usala solo per provare. Prima di distribuire l'app ad altri, sostituiscila con una chiave tua nuova da [aistudio.google.com/api-keys](https://aistudio.google.com/api-keys) e inseriscila nelle Impostazioni dell'app (resta solo sul telefono).

## Via 2 — Con il computer (Expo, la più rapida per sviluppare)

```bash
npm install
npx expo start          # scansiona il QR con Expo Go per provare live
```

Poi per l'APK nel cloud (richiede account Expo gratuito, login con `eas login`):

```bash
npm install -g eas-cli
eas build -p android --profile preview   # profilo già configurato: produce .apk
```

Expo ti dà un link per scaricare l'APK: installalo sul telefono come sopra.

## Via 3 — Pubblicazione su Google Play

1. Account **Google Play Console**: 25 $ una tantum ([play.google.com/console](https://play.google.com/console)).
2. Genera il bundle firmato: `eas build -p android --profile production` (produce un `.aab`, profilo già pronto in `eas.json`).
3. Su Play Console: crea l'app → scheda "Produzione" → carica il `.aab` → compila la scheda store (nome, descrizione, screenshot, privacy policy).
4. L'app dichiara già i permessi `RECORD_AUDIO` e `CAMERA` in `app.json`: nella dichiarazione di Play indica che microfono e fotocamera sono opzionali e usati solo su richiesta dell'utente.
5. Invia per la revisione (di solito pochi giorni la prima volta).

---

## Perché la chiave Gemini è già "attiva" ma va cambiata

- Il formato nuovo `AQ.` delle chiavi Google funziona solo via header `x-goog-api-key`: il router di Aether è già aggiornato a questo comportamento.
- Ogni utente che avrà l'app può usare la **propria** chiave inserendola nelle Impostazioni: così i tuoi costi API restano tuoi e l'app resta gratis per chi la usa.

## Problemi comuni

| Problema | Soluzione |
|---|---|
| "Tutti i provider hanno dato errore" in chat | Chiave non valida o quota esaurita: controlla in [aistudio.google.com/api-keys](https://aistudio.google.com/api-keys) |
| L'APK non si installa | Abilita "Installa app sconosciute" per l'app con cui lo apri |
| Bloccato su un pagamento Play | Puoi distribuire l'APK direttamente (Via 1/2): Play non è obbligatorio |
| Voce assente | `npm install expo-speech` e ricostruisci (MVP: la voce viene caricata solo se il modulo c'è) |
