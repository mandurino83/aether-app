# ✦ Aether — MVP ufficiale (solo smartphone)

Assistente vocale per iPhone e Android. Privacy-first: nessun account, nessuna telemetria, memoria cifrata sul telefono, API key dell'utente (BYO), router multi-modello con **fallback automatico**.

> ⚠️ Onestà prima di tutto: **nessuno può generare una app completa con tutte le funzioni elencate senza scriverla davvero**. Quello che trovi qui è un **MVP reale, funzionante e compilabile** — la base da cui costruire tutto il resto, con una roadmap chiara per arrivarci.

---

## Cosa c'è dentro l'MVP (funziona davvero, ora)

| Funzione | Stato | Note |
|---|---|---|
| Chat testuale con AI | ✅ Fatto | storage locale della cronologia |
| Router multi-provider con fallback | ✅ Fatto | Gemini, OpenAI/GPT, Claude, Grok; prova in ordine e passa al successivo se uno fallisce |
| BYO API key (nessun account) | ✅ Fatto | chiavi salvate solo sul telefono |
| Memoria a lungo termine **cifrata** | ✅ Fatto | aggiungi / vedi / modifica / elimina ogni ricordo |
| Esporta tutta la memoria in JSON | ✅ Fatto | un tap, dal pannello Memoria |
| Cancella tutto (privacy) | ✅ Fatto | con conferma |
| 12 agenti/personalità pronti | ✅ Fatto | Aether, Jarvis, Ultron, Study Buddy, Language Tutor, Inbox Zero, Life Admin, Pitch Practice, Hard Conversation, Quiz Night, On the Move, Focus |
| TTS (voce di risposta) | ✅ Fatto | via `expo-speech` quando installato; degrada senza crash |
| UI scura premium, 4 tab, one-hand | ✅ Fatto | React Native + StyleSheet |
| Typecheck TypeScript | ✅ Passato | `tsc --noEmit` → 0 errori |
| STT on-device (whisper.cpp) | 🔜 M2 | l'adattatore c'è già, il modulo nativo va collegato |
| Modelli locali (llama.cpp / Gemma 3n) | 🔜 M3 | UI pronta, server locale da collegare |
| Visione (fotocamera/documenti) | 🔜 M2–M3 | permessi già dichiarati in `app.json` |
| Controllo del telefono, automazioni, widget | 🔜 M4+ | vedi limiti reali qui sotto |

## Stack scelto (e perché)

**Expo / React Native + TypeScript.**
- Un solo codice → iOS + Android, come richiesto (solo smartphone).
- Expo ti permette di **provare l'app SUBITO dal telefono** con l'app **Expo Go**, senza Mac e senza Android Studio.
- Ecosistema maturo per i moduli nativi che serviranno (whisper.cpp binding, expo-speech, SecureStore).
- TypeScript = meno crash = la stabilità che hai chiesto.

## Requisiti reali verificati (30 settembre 2026)

**Costi per pubblicare:**
- Apple Developer Program: **99 $/anno** (obbligatorio per App Store e TestFlight)
- Google Play Console: **25 $ una tantum** — e la commissione sugli abbonamenti/in-app è scesa (15–20% a seconda dei casi, non più 30% fisso)

**Prezzi API (indicativi, per 1M di token, a cui l'ultima volta ho controllato i listini: verifica sempre su ai.google.dev / developers.openai.com prima del lancio):**
- Gemini Flash: input da ~0,10–0,30 $, output da ~0,40–2,50 $ (i modelli Flash-Lite sono i più economici)
- OpenAI GPT Realtime (voce in tempo reale): molto più caro (~10–64 $/M token audio) → per la voce conviene STT locale + LLM testuale, come fa questo MVP
- Claude e Grok: fasce simili a GPT, vedi i portali ufficiale

**Limiti iOS da sapere ORA (per non promettere cose impossibili):**
- ❌ **Wake-word personalizzata in background**: iOS la riserva a Siri, non esiste API pubblica. Soluzione: "Dynamic Island"/widget/azione rapida, oppure hands-free solo con schermo attivo. Su Android invece è fattibile con un foreground service.
- ❌ **Leggere la mail in background senza che l'utente lo permetta**: su iOS non puoi accedere a Mail; va usato il forwarding a un indirizzo dedicato o Gmail API con consenso esplicito dell'utente (anche su Android).
- ⚠️ **Controllo del telefono**: limitato ai meccanismi ufficiali (Shortcuts/Intent, AccessibilityService su Android con giustificazione). Niente controllo totale alla Jarvis.
- ✅ STT on-device (whisper.cpp), LLM on-device leggeri (Gemma 3n ~1–4B, Llama 3.2, Phi-4 Mini) e memoria cifrata: **tutto fattibile su entrambe le piattaforme**.

---

## Come provarlo ADESSO dal telefono (5 minuti, zero soldi)

1. Scarica **Expo Go** da App Store o Play Store.
2. Sul PC (o in un ambiente come GitHub Codespaces):
   ```bash
   npm install
   npx expo start
   ```
3. Scansiona il QR code con Expo Go → l'app parte sul telefono.
4. Vai in **Impostazioni**, incolla una API key (es. Gemini) → vai in **Chat** e scrivi.
5. Vai in **Memoria** → salva un ricordo → vedrai che è cifrato; puoi esportarlo o cancellarlo quando vuoi.

## Come costruire le versioni installabili

**Android (APK da distribuire subito):**
```bash
npm install -g eas-cli
eas login
eas build -p android --profile preview   # genera un .apk
```
Poi Play Console (25 $ una tantum) per la pubblicazione, o distribuzione diretta dell'APK.

**iOS (serve un Mac, o EAS Build nel cloud):**
```bash
eas build -p ios           # funziona anche senza Mac (EAS cloud)
eas submit -p ios          # invia ad App Store Connect / TestFlight
```
Con TestFlight i tester provano l'app prima del lancio. Account Apple: 99 $/anno.

**Alternative low-code (se non vuoi scrivere codice):** FlutterFlow, Rork, Replit Agent o affidare questo repo a uno sviluppatore freelance — il progetto è già strutturato e tipizzato per essere preso in carico.

## Roadmap

- **M1 (questo MVP)** — chat multi-provider + fallback, memoria cifrata esportabile, 12 agenti, TTS, UI scura.
- **M2 — Voce completa**: STT on-device con whisper.cpp (binding nativo), push-to-talk + barge-in, wake-word su Android, rifinitura "On the Move".
- **M3 — Locale e Visione**: server llama.cpp/Ollama per i modelli locali (Gemma 3n, Llama 3.2 3B), fotocamera + documenti, screenshot.
- **M4 — Produttività**: Gmail/Google Calendar API con consenso esplicito (Inbox Zero reale), reminder nativi, Life Admin con checklist.
- **M5 — Automazioni**: workflow multi-step salvabili e condivisibili, scorciatoie iOS / Intents Android.
- **M6 — Business**: piano Pro opzionale (cloud avanzato, memoria estesa), pubblicazione negozi.

## Sicurezza (importante)

La cifratura dell'MVP usa un cipher stream scritto a mano (sufficiente per sviluppare, **non** per la produzione). Prima del rilascio:
1. Sostituisci `src/lib/crypto.ts` con **AES-256** via `expo-crypto`/SQLCipher;
2. Sposta la master key in **SecureStore (iOS Keychain) / Android Keystore**;
3. Rifai il typecheck: le firme delle funzioni restano identiche, il resto del codice non cambia.

## Struttura del progetto

```
aether-mvp/
├── App.tsx                  # UI completa: 4 tab, chat, memoria, agenti, impostazioni
├── index.ts                 # entry point
├── app.json                 # config Expo (permessi mic/fotocamera già dichiarati)
├── decls.d.ts               # stub tipizzati dei moduli nativi
├── src/
│   ├── theme.ts             # tema scuro premium
│   ├── types.ts             # tipi condivisi
│   ├── data/agents.ts       # 12 personalità builtin
│   └── lib/
│       ├── router.ts        # router multi-provider + fallback automatico
│       ├── memoryStore.ts   # memoria: CRUD + export + wipe
│       ├── crypto.ts        # cifratura a riposo (→ AES in produzione)
│       ├── prompt.ts        # system prompt con iniezione della memoria
│       └── voice.ts         # adattatore TTS (expo-speech) e stub STT
```
