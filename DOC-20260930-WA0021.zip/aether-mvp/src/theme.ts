// Aether — tema scuro premium (solo smartphone, one-hand UX)
export const theme = {
  bg: "#0B0F14",
  bgElevated: "#121821",
  bgCard: "#161E2A",
  accent: "#5EEAD4",
  accentDim: "#2DD4BF33",
  text: "#E6EDF3",
  textDim: "#8B98A5",
  danger: "#F87171",
  ok: "#34D399",
  warn: "#FBBF24",
  radius: 16,
  spacing: 16,
};
