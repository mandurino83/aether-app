import AsyncStorage from "@react-native-async-storage/async-storage";
import { MemoryItem } from "../types";
import { decryptString, encryptString } from "./crypto";

// Memoria a lungo termine: ogni ricordo è cifrato a riposo.
// Operazioni: aggiungi, elenca (decifrato), modifica, cancella singolo,
// esporta tutto in JSON, cancella tutto (un tap).
const STORE_KEY = "aether.memory.v1";

async function readAll(): Promise<MemoryItem[]> {
  const raw = await AsyncStorage.getItem(STORE_KEY);
  if (!raw) return [];
  try {
    const decrypted = await decryptString(raw);
    return JSON.parse(decrypted) as MemoryItem[];
  } catch {
    return [];
  }
}

async function writeAll(items: MemoryItem[]): Promise<void> {
  await AsyncStorage.setItem(STORE_KEY, await encryptString(JSON.stringify(items)));
}

export const memoryStore = {
  async add(category: MemoryItem["category"], title: string, content: string): Promise<MemoryItem> {
    const items = await readAll();
    const now = Date.now();
    const item: MemoryItem = { id: `m${now}${Math.random().toString(36).slice(2, 7)}`, category, title, content, createdAt: now, updatedAt: now };
    items.unshift(item);
    await writeAll(items);
    return item;
  },
  async list(): Promise<MemoryItem[]> {
    return readAll();
  },
  async update(id: string, patch: Partial<Pick<MemoryItem, "category" | "title" | "content">>): Promise<void> {
    const items = await readAll();
    const idx = items.findIndex((m) => m.id === id);
    if (idx >= 0) {
      items[idx] = { ...items[idx], ...patch, updatedAt: Date.now() };
      await writeAll(items);
    }
  },
  async remove(id: string): Promise<void> {
    await writeAll((await readAll()).filter((m) => m.id !== id));
  },
  async exportAll(): Promise<string> {
    return JSON.stringify(await readAll(), null, 2);
  },
  async wipeAll(): Promise<void> {
    await AsyncStorage.removeItem(STORE_KEY);
  },
  async search(query: string): Promise<MemoryItem[]> {
    const q = query.toLowerCase();
    return (await readAll()).filter(
      (m) => m.title.toLowerCase().includes(q) || m.content.toLowerCase().includes(q) || m.category.includes(q)
    );
  },
};
