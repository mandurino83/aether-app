// Adattatore voce: prova a usare i moduli nativi se installati
// (expo-speech per il TTS; per lo STT on-device si collega whisper.cpp o
// expo-speech-recognition nella roadmap M2). In questo scaffold degrada
// con grazia a solo-testo senza crash.

interface SpeechModule {
  speak(text: string, opts?: { language?: string; rate?: number }): void;
  stop(): void;
}

let speechModule: SpeechModule | null | undefined;

function tryLoadSpeech(): SpeechModule | null {
  if (speechModule !== undefined) return speechModule;
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const expoSpeech = require("expo-speech");
    speechModule = {
      speak: (text, opts) => expoSpeech.speak(text, { language: opts?.language ?? "it-IT", rate: opts?.rate ?? 1.0 }),
      stop: () => expoSpeech.stop(),
    };
  } catch {
    speechModule = null; // modulo nativo non installato: nessun crash
  }
  return speechModule;
}

export const voice = {
  speak(text: string): void {
    const mod = tryLoadSpeech();
    mod?.speak(text.slice(0, 3000));
  },
  stopSpeaking(): void {
    const mod = tryLoadSpeech();
    mod?.stop();
  },
  // Lo STT on-device (whisper.cpp) sarà collegato nella Milestone M2.
  isSpeechToTextAvailable(): boolean {
    return false;
  },
};
