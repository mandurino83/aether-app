import { Message, ProviderConfig } from "../types";

// Router multi-modello con fallback automatico.
// Prova i provider abilitati NELL'ORDINE con cui sono configurati;
// se uno fallisce (chiave errata, quota, rete, outage) passa al successivo
// senza interrompere la conversazione. Nessun dato in uscita se non verso
// i provider che l'utente ha esplicitamente configurato (BYO API key).

export interface RouterResult {
  text: string;
  provider: string;
  fellBack: boolean;
  errors: string[];
}

const TIMEOUT_MS = 30000;

async function fetchWithTimeout(url: string, init: RequestInit): Promise<Response> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal });
  } finally {
    clearTimeout(t);
  }
}

async function callOpenAICompatible(p: ProviderConfig, system: string, msgs: Message[]): Promise<string> {
  const res = await fetchWithTimeout("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${p.apiKey}` },
    body: JSON.stringify({
      model: p.model || "gpt-4o-mini",
      messages: [{ role: "system", content: system }, ...msgs.map((m) => ({ role: m.role, content: m.text }))],
    }),
  });
  if (!res.ok) throw new Error(`OpenAI ${res.status}: ${await res.text()}`);
  const json = await res.json();
  return json.choices?.[0]?.message?.content ?? "(risposta vuota)";
}

async function callGemini(p: ProviderConfig, system: string, msgs: Message[]): Promise<string> {
  const model = p.model || "gemini-2.5-flash";
  // Le nuove chiavi Google (formato "AQ.") funzionano SOLO tramite header
  // x-goog-api-key: la chiave nell'URL (?key=) viene rifiutata.
  const res = await fetchWithTimeout(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": p.apiKey },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: system }] },
        contents: msgs.map((m) => ({
          role: m.role === "assistant" ? "model" : "user",
          parts: [{ text: m.text }],
        })),
      }),
    }
  );
  if (!res.ok) throw new Error(`Gemini ${res.status}: ${await res.text()}`);
  const json = await res.json();
  return json.candidates?.[0]?.content?.parts?.[0]?.text ?? "(risposta vuota)";
}

async function callAnthropic(p: ProviderConfig, system: string, msgs: Message[]): Promise<string> {
  const res = await fetchWithTimeout("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": p.apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model: p.model || "claude-sonnet-4-5",
      max_tokens: 1024,
      system,
      messages: msgs
        .filter((m) => m.role !== "system")
        .map((m) => ({ role: m.role, content: m.text })),
    }),
  });
  if (!res.ok) throw new Error(`Claude ${res.status}: ${await res.text()}`);
  const json = await res.json();
  return json.content?.[0]?.text ?? "(risposta vuota)";
}

async function callXai(p: ProviderConfig, system: string, msgs: Message[]): Promise<string> {
  const res = await fetchWithTimeout("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${p.apiKey}` },
    body: JSON.stringify({
      model: p.model || "grok-3-mini",
      messages: [{ role: "system", content: system }, ...msgs.map((m) => ({ role: m.role, content: m.text }))],
    }),
  });
  if (!res.ok) throw new Error(`Grok ${res.status}: ${await res.text()}`);
  const json = await res.json();
  return json.choices?.[0]?.message?.content ?? "(risposta vuota)";
}

async function dispatch(p: ProviderConfig, system: string, msgs: Message[]): Promise<string> {
  switch (p.id) {
    case "gemini":
      return callGemini(p, system, msgs);
    case "openai":
      return callOpenAICompatible(p, system, msgs);
    case "anthropic":
      return callAnthropic(p, system, msgs);
    case "xai":
      return callXai(p, system, msgs);
    case "local":
      throw new Error("Server locale non ancora collegato (roadmap M3)");
  }
}

export async function routeChat(
  providers: ProviderConfig[],
  system: string,
  msgs: Message[]
): Promise<RouterResult> {
  const active = providers.filter((p) => p.enabled && (p.apiKey.length > 0 || p.id === "local"));
  const errors: string[] = [];
  if (active.length === 0) {
    return {
      text: "Nessun provider configurato. Vai in Impostazioni e inserisci la tua API key (Gemini, GPT, Claude o Grok). Tutto resta sul telefono.",
      provider: "none",
      fellBack: false,
      errors,
    };
  }
  for (let i = 0; i < active.length; i++) {
    try {
      const text = await dispatch(active[i], system, msgs);
      return { text, provider: active[i].label, fellBack: i > 0, errors };
    } catch (e) {
      errors.push(`${active[i].label}: ${e instanceof Error ? e.message : String(e)}`);
    }
  }
  return {
    text: "Tutti i provider hanno dato errore. Controlla le chiavi in Impostazioni.\n\n" + errors.join("\n"),
    provider: "error",
    fellBack: true,
    errors,
  };
}
