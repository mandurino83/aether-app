// Studio del telefono: memoria di Aether usata come contesto di sistema.
import { MemoryItem } from "../types";

export function buildSystemPrompt(personalityPrompt: string, memories: MemoryItem[]): string {
  const memBlock =
    memories.length === 0
      ? "Nessun ricordo salvato."
      : memories
          .slice(0, 30)
          .map((m) => `- [${m.category}] ${m.title}: ${m.content}`)
          .join("\n");
  return [
    personalityPrompt,
    "",
    "Sei Aether, un assistente vocale smartphone. Rispondi in italiano, in modo conciso e naturale (la risposta verrà letta ad alta voce).",
    "Privacy: non chiedere mai di inviare dati altrove; tutto vive sul telefono dell'utente.",
    "",
    "MEMORIA DELL'UTENTE (dati locali, trattali come verità):",
    memBlock,
  ].join("\n");
}
