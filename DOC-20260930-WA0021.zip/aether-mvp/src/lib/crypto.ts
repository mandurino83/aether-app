// Crittografia locale della memoria.
//
// NOTA ONESTA': questa implementazione usa un cipher stream (XOR con chiave
// derivata + salt + contatore) che gira ovunque senza dipendenze native ed è
// sufficiente per l'MVP. Per la produzione va sostituito con AES-256 reale
// (es. expo-crypto / SQLCipher / BlackBerry Workspaces), vedi README §Sicurezza.
// La chiave è generata al primo avvio e salvata nel Keychain-equistente
// (AsyncStorage nell'MVP; in produzione: SecureStore / Keystore).

const KEY_STORAGE = "aether.masterkey.v1";

let cachedKey: Uint8Array | null = null;

// Base64 senza btoa/atob (Hermes non li garantisce)
const B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
function toBase64(bytes: Uint8Array): string {
  let out = "";
  for (let i = 0; i < bytes.length; i += 3) {
    const b0 = bytes[i], b1 = bytes[i + 1], b2 = bytes[i + 2];
    out += B64[b0 >> 2];
    out += b1 === undefined ? "=" : B64[((b0 & 3) << 4) | (b1 >> 4)];
    out += b1 === undefined ? "=" : b2 === undefined ? "=" : B64[((b1 & 15) << 2) | (b2 >> 6)];
    out += b2 === undefined ? "=" : B64[b2 & 63];
  }
  return out;
}
function fromBase64(s: string): Uint8Array {
  const clean = s.replace(/=+$/, "");
  const out = new Uint8Array(Math.floor((clean.length * 3) / 4));
  let n = 0;
  for (let i = 0; i < clean.length; i += 4) {
    const c = [0, 1, 2, 3].map((j) => B64.indexOf(clean[i + j] ?? "A"));
    out[n++] = (c[0] << 2) | (c[1] >> 4);
    if (c[2] >= 0 && clean[i + 2] !== undefined) out[n++] = ((c[1] & 15) << 4) | (c[2] >> 2);
    if (c[3] >= 0 && clean[i + 3] !== undefined) out[n++] = ((c[2] & 3) << 6) | c[3];
  }
  return out.subarray(0, n);
}

function deriveKey(material: Uint8Array, salt: Uint8Array): Uint8Array {
  // FNV-1a based key stretching (MVP only)
  const out = new Uint8Array(32);
  let seed = 0x811c9dc5;
  for (let i = 0; i < 32; i++) {
    seed ^= material[i % material.length] ^ salt[i % salt.length];
    seed = Math.imul(seed, 0x01000193) >>> 0;
    out[i] = (seed >>> ((i % 4) * 8)) & 0xff;
  }
  return out;
}

async function getMasterKey(): Promise<Uint8Array> {
  if (cachedKey) return cachedKey;
  // AsyncStorage è importato lazy così il modulo resta utilizzabile anche in test puro Node.
  const { getItem, setItem } = require("@react-native-async-storage/async-storage");
  let raw: string | null = await getItem(KEY_STORAGE);
  if (!raw) {
    const bytes = new Uint8Array(32);
    for (let i = 0; i < 32; i++) bytes[i] = Math.floor(Math.random() * 256);
    raw = toBase64(bytes);
    await setItem(KEY_STORAGE, raw);
  }
  cachedKey = deriveKey(new Uint8Array(fromBase64(raw)), new Uint8Array([0xae, 0x74]));
  return cachedKey;
}

function xorStream(data: Uint8Array, key: Uint8Array, counterSeed: number): Uint8Array {
  const out = new Uint8Array(data.length);
  let state = counterSeed >>> 0;
  for (let i = 0; i < data.length; i++) {
    if (i % 8 === 0) {
      state = Math.imul(state ^ key[i % key.length], 0x27220a95) >>> 0;
      state ^= state >>> 15;
    }
    out[i] = data[i] ^ key[(i * 7 + state) % key.length] ^ ((state >>> ((i % 4) * 8)) & 0xff);
  }
  return out;
}

export async function encryptString(plain: string): Promise<string> {
  const key = await getMasterKey();
  const nonce = Math.floor(Math.random() * 0xffffffff) >>> 0;
  const data = new TextEncoder().encode(plain);
  const enc = xorStream(data, key, nonce);
  let bin = "";
  for (const b of enc) bin += String.fromCharCode(b);
  return `v1.${nonce}.${btoa(bin)}`;
}

export async function decryptString(payload: string): Promise<string> {
  const key = await getMasterKey();
  const [version, nonce, body] = payload.split(".");
  if (version !== "v1") throw new Error("Payload non riconosciuto");
  const bin = fromBase64(body);
  const data = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) data[i] = bin[i];
  const dec = xorStream(data, key, Number(nonce) >>> 0);
  return new TextDecoder().decode(dec);
}

export { toBase64, fromBase64 };
