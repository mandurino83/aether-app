// Tipi condivisi di Aether MVP
export type Role = "user" | "assistant" | "system";

export interface Message {
  id: string;
  role: Role;
  text: string;
  ts: number;
  provider?: string; // quale modello ha risposto
}

export type ProviderId = "gemini" | "openai" | "anthropic" | "xai" | "local";

export interface ProviderConfig {
  id: ProviderId;
  label: string;
  apiKey: string;
  model: string;
  enabled: boolean;
}

// Ordine = priorità. Il router prova in sequenza e fa fallback automatico.
export interface Settings {
  providers: ProviderConfig[];
  activePersonalityId: string;
  speechToText: "auto" | "text-only";
}

export interface MemoryItem {
  id: string;
  category: "persona" | "progetto" | "preferenza" | "abitudine" | "altro";
  title: string;
  content: string;
  createdAt: number;
  updatedAt: number;
}

export interface Personality {
  id: string;
  name: string;
  emoji: string;
  description: string;
  systemPrompt: string;
  builtin: boolean;
}
