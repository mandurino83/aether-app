import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from "react-native";
import { theme } from "./src/theme";
import { Message, Personality, ProviderId, Settings } from "./src/types";
import { builtinPersonalities } from "./src/data/agents";
import { routeChat } from "./src/lib/router";
import { memoryStore } from "./src/lib/memoryStore";
import { buildSystemPrompt } from "./src/lib/prompt";
import { voice } from "./src/lib/voice";

const DEFAULT_SETTINGS: Settings = {
  providers: [
    // Chiave Google AI Studio preconfigurata (nuovo formato "AQ.").
    // Sostituiscila con una tua da aistudio.google.com/api-keys prima di distribuire l'app.
    { id: "gemini", label: "Gemini", apiKey: "AQ.Ab8RN6IUl9yleNeFRusIzYHOjP4dgwpI_EiCuGDbEIHuNqCE-A", model: "gemini-2.5-flash", enabled: true },
    { id: "openai", label: "OpenAI (GPT)", apiKey: "", model: "gpt-4o-mini", enabled: false },
    { id: "anthropic", label: "Claude", apiKey: "", model: "claude-sonnet-4-5", enabled: false },
    { id: "xai", label: "Grok", apiKey: "", model: "grok-3-mini", enabled: false },
    { id: "local", label: "Modello locale", apiKey: "", model: "-", enabled: false },
  ],
  activePersonalityId: "aether",
  speechToText: "auto",
};

const SETTINGS_KEY = "aether.settings.v1";
const CHAT_KEY = "aether.chat.v1";

function storage(): {
  getItem: (k: string) => Promise<string | null>;
  setItem: (k: string, v: string) => Promise<void>;
  removeItem: (k: string) => Promise<void>;
} {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  return require("@react-native-async-storage/async-storage");
}

type Tab = "chat" | "agents" | "memory" | "settings";

export default function App() {
  const [tab, setTab] = useState<Tab>("chat");
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [messages, setMessages] = useState<Message[]>([]);
  const [memories, setMemories] = useState<Awaited<ReturnType<typeof memoryStore.list>>>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [showExport, setShowExport] = useState(false);
  const [exportText, setExportText] = useState("");

  // --- persistenza ---
  useEffect(() => {
    (async () => {
      try {
        const s = await storage().getItem(SETTINGS_KEY);
        if (s) setSettings({ ...DEFAULT_SETTINGS, ...(JSON.parse(s) as Settings) });
        const c = await storage().getItem(CHAT_KEY);
        if (c) setMessages(JSON.parse(c) as Message[]);
        setMemories(await memoryStore.list());
      } catch {
        // primo avvio: nessun dato
      }
    })();
  }, []);

  const persistSettings = useCallback(async (s: Settings) => {
    setSettings(s);
    try {
      await storage().setItem(SETTINGS_KEY, JSON.stringify(s));
    } catch {}
  }, []);

  const persistChat = useCallback(async (m: Message[]) => {
    setMessages(m);
    try {
      await storage().setItem(CHAT_KEY, JSON.stringify(m.slice(-100)));
    } catch {}
  }, []);

  const activePersonality: Personality = useMemo(
    () =>
      builtinPersonalities.find((p) => p.id === settings.activePersonalityId) ??
      builtinPersonalities[0],
    [settings.activePersonalityId]
  );

  // --- invio messaggio ---
  const send = useCallback(async () => {
    const text = input.trim();
    if (!text || busy) return;
    setInput("");
    const userMsg: Message = { id: `u${Date.now()}`, role: "user", text, ts: Date.now() };
    const history = [...messages, userMsg];
    await persistChat(history);
    setBusy(true);
    try {
      const sys = buildSystemPrompt(activePersonality.systemPrompt, memories);
      const result = await routeChat(settings.providers, sys, history);
      const aiMsg: Message = {
        id: `a${Date.now()}`,
        role: "assistant",
        text: result.text,
        ts: Date.now(),
        provider: result.provider,
      };
      await persistChat([...history, aiMsg]);
      voice.speak(result.text);
      if (result.fellBack && result.provider !== "error" && result.errors.length > 0) {
        // fallback avvenuto: avvisa una sola volta in whisper nel log, senza allarmare
      }
    } catch (e) {
      const errMsg: Message = {
        id: `e${Date.now()}`,
        role: "assistant",
        text: `Errore inatteso: ${e instanceof Error ? e.message : String(e)}`,
        ts: Date.now(),
        provider: "error",
      };
      await persistChat([...history, errMsg]);
    } finally {
      setBusy(false);
    }
  }, [activePersonality, busy, input, memories, messages, persistChat, settings.providers]);

  // --- memoria ---
  const [memTitle, setMemTitle] = useState("");
  const [memContent, setMemContent] = useState("");
  const addMemory = useCallback(async () => {
    if (!memTitle.trim()) return;
    await memoryStore.add("altro", memTitle.trim(), memContent.trim());
    setMemTitle("");
    setMemContent("");
    setMemories(await memoryStore.list());
  }, [memContent, memTitle]);

  const wipeMemory = useCallback(() => {
    Alert.alert("Cancellare tutta la memoria?", "Operazione irreversibile.", [
      { text: "Annulla", style: "cancel" },
      {
        text: "Cancella tutto",
        style: "destructive",
        onPress: async () => {
          await memoryStore.wipeAll();
          setMemories([]);
        },
      },
    ]);
  }, []);

  const exportMemory = useCallback(async () => {
    setExportText(await memoryStore.exportAll());
    setShowExport(true);
  }, []);

  const resetChat = useCallback(async () => {
    await storage().removeItem(CHAT_KEY);
    setMessages([]);
  }, []);

  // --- rendering ---
  return (
    <View style={styles.root}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>✦ Aether</Text>
        <Text style={styles.headerSub}>{activePersonality.emoji} {activePersonality.name}</Text>
      </View>

      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={90}
      >
        {tab === "chat" && (
          <View style={styles.flex}>
            <FlatList
              style={styles.flex}
              contentContainerStyle={styles.chatList}
              data={messages}
              keyExtractor={(m: Message) => m.id}
              ListEmptyComponent={
                <View style={styles.empty}>
                  <Text style={styles.emptyOrb}>✦</Text>
                  <Text style={styles.emptyText}>
                    Ciao. Scrivi qui sotto: le tue API key restano sul telefono e i ricordi sono cifrati.
                  </Text>
                </View>
              }
              renderItem={({ item }: { item: Message }) => (
                <View style={[styles.bubble, item.role === "user" ? styles.bubbleUser : styles.bubbleAi]}>
                  <Text style={styles.bubbleText}>{item.text}</Text>
                  {item.provider ? <Text style={styles.bubbleMeta}>{item.provider}</Text> : null}
                </View>
              )}
            />
            {messages.length > 0 && (
              <Pressable onPress={resetChat} style={styles.linkRow}>
                <Text style={styles.link}>Nuova conversazione</Text>
              </Pressable>
            )}
            <View style={styles.inputRow}>
              <TextInput
                style={styles.input}
                placeholder={voice.isSpeechToTextAvailable() ? "Parla o scrivi…" : "Scrivi ad Aether… (voce in M2)"}
                placeholderTextColor={theme.textDim}
                value={input}
                onChangeText={setInput}
                multiline
              />
              <Pressable style={[styles.sendBtn, busy && styles.sendBtnBusy]} onPress={send} disabled={busy}>
                {busy ? <ActivityIndicator color={theme.bg} /> : <Text style={styles.sendText}>➤</Text>}
              </Pressable>
            </View>
          </View>
        )}

        {tab === "agents" && (
          <ScrollView contentContainerStyle={styles.listPad}>
            {builtinPersonalities.map((p) => {
              const active = p.id === settings.activePersonalityId;
              return (
                <Pressable
                  key={p.id}
                  style={[styles.card, active && styles.cardActive]}
                  onPress={() => persistSettings({ ...settings, activePersonalityId: p.id })}
                >
                  <Text style={styles.cardTitle}>{p.emoji} {p.name}{active ? "  ✓ attivo" : ""}</Text>
                  <Text style={styles.cardBody}>{p.description}</Text>
                </Pressable>
              );
            })}
            <Text style={styles.footNote}>
              Nella roadmap: creazione di agenti personalizzati, workflow multi-step e condivisione.
            </Text>
          </ScrollView>
        )}

        {tab === "memory" && (
          <View style={styles.flex}>
            <ScrollView contentContainerStyle={styles.listPad} style={styles.flex}>
              <View style={styles.card}>
                <Text style={styles.cardTitle}>Nuovo ricordo</Text>
                <TextInput
                  style={styles.field}
                  placeholder="Titolo (es. Chiave di casa)"
                  placeholderTextColor={theme.textDim}
                  value={memTitle}
                  onChangeText={setMemTitle}
                />
                <TextInput
                  style={[styles.field, styles.fieldMultiline]}
                  placeholder="Contenuto"
                  placeholderTextColor={theme.textDim}
                  value={memContent}
                  onChangeText={setMemContent}
                  multiline
                />
                <Pressable style={styles.primaryBtn} onPress={addMemory}>
                  <Text style={styles.primaryBtnText}>Salva ricordo (cifrato)</Text>
                </Pressable>
              </View>
              {memories.map((m) => (
                <View key={m.id} style={styles.card}>
                  <Text style={styles.cardTitle}>[{m.category}] {m.title}</Text>
                  <Text style={styles.cardBody}>{m.content}</Text>
                  <Pressable
                    onPress={async () => {
                      await memoryStore.remove(m.id);
                      setMemories(await memoryStore.list());
                    }}
                  >
                    <Text style={styles.link}>Elimina</Text>
                  </Pressable>
                </View>
              ))}
              {memories.length === 0 && (
                <Text style={styles.footNote}>Nessun ricordo. Tutto ciò che salvi è cifrato sul telefono.</Text>
              )}
            </ScrollView>
            <View style={styles.memActions}>
              <Pressable style={styles.ghostBtn} onPress={exportMemory}>
                <Text style={styles.ghostBtnText}>Esporta JSON</Text>
              </Pressable>
              <Pressable style={[styles.ghostBtn, styles.ghostDanger]} onPress={wipeMemory}>
                <Text style={styles.ghostBtnText}>Cancella tutto</Text>
              </Pressable>
            </View>
          </View>
        )}

        {tab === "settings" && (
          <ScrollView contentContainerStyle={styles.listPad}>
            <Text style={styles.footNote}>
              Porta la tua chiave (BYO): nessun account, nessuna telemetria. I provider abilitati
              vengono provati in ordine; se uno fallisce, Aether passa automaticamente al successivo.
            </Text>
            {settings.providers.map((p, i) => (
              <View key={p.id} style={styles.card}>
                <View style={styles.rowBetween}>
                  <Text style={styles.cardTitle}>{p.label}</Text>
                  <Switch
                    value={p.enabled}
                    onValueChange={(v: boolean) => {
                      const next = [...settings.providers];
                      next[i] = { ...p, enabled: v };
                      persistSettings({ ...settings, providers: next });
                    }}
                  />
                </View>
                <TextInput
                  style={styles.field}
                  placeholder="API key"
                  placeholderTextColor={theme.textDim}
                  value={p.apiKey}
                  secureTextEntry
                  autoCapitalize="none"
                  onChangeText={(v: string) => {
                    const next = [...settings.providers];
                    next[i] = { ...p, apiKey: v };
                    persistSettings({ ...settings, providers: next });
                  }}
                />
                {p.id !== "local" && (
                  <TextInput
                    style={styles.field}
                    placeholder="Modello"
                    placeholderTextColor={theme.textDim}
                    value={p.model}
                    autoCapitalize="none"
                  onChangeText={(v: string) => {
                    const next = [...settings.providers];
                    next[i] = { ...p, model: v };
                      persistSettings({ ...settings, providers: next });
                    }}
                  />
                )}
                {p.id === "local" && <Text style={styles.footNote}>Server locale (llama.cpp/Ollama): roadmap M3.</Text>}
              </View>
            ))}
            <Text style={styles.footNote}>
              Nella roadmap: clonazione voce, visione con fotocamera, controllo del telefono,
              automazioni e modalità offline completa.
            </Text>
          </ScrollView>
        )}
      </KeyboardAvoidingView>

      <View style={styles.tabBar}>
        {([
          ["chat", "💬", "Chat"],
          ["agents", "🤖", "Agenti"],
          ["memory", "🧠", "Memoria"],
          ["settings", "⚙️", "Impostazioni"],
        ] as [Tab, string, string][]).map(([id, icon, label]) => (
          <Pressable key={id} style={styles.tabItem} onPress={() => setTab(id)}>
            <Text style={[styles.tabIcon, tab === id && styles.tabIconActive]}>{icon}</Text>
            <Text style={[styles.tabLabel, tab === id && styles.tabLabelActive]}>{label}</Text>
          </Pressable>
        ))}
      </View>

      <Modal visible={showExport} animationType="slide">
        <View style={styles.modalRoot}>
          <Text style={styles.cardTitle}>Esporta memoria (JSON)</Text>
          <TextInput style={[styles.field, styles.exportBox]} multiline value={exportText} editable={false} />
          <Pressable style={styles.primaryBtn} onPress={() => setShowExport(false)}>
            <Text style={styles.primaryBtnText}>Chiudi</Text>
          </Pressable>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: theme.bg, paddingTop: Platform.OS === "ios" ? 48 : 24 },
  flex: { flex: 1 },
  header: { paddingHorizontal: theme.spacing, paddingBottom: 8 },
  headerTitle: { color: theme.text, fontSize: 24, fontWeight: "800" },
  headerSub: { color: theme.accent, fontSize: 13, marginTop: 2 },
  chatList: { padding: theme.spacing, gap: 10 },
  empty: { alignItems: "center", marginTop: 60, padding: 24 },
  emptyOrb: { color: theme.accent, fontSize: 48, marginBottom: 12 },
  emptyText: { color: theme.textDim, textAlign: "center", lineHeight: 20 },
  bubble: { maxWidth: "88%", borderRadius: theme.radius, padding: 12, marginVertical: 4 },
  bubbleUser: { backgroundColor: "#1F3B4D", alignSelf: "flex-end" },
  bubbleAi: { backgroundColor: theme.bgCard, alignSelf: "flex-start" },
  bubbleText: { color: theme.text, lineHeight: 20 },
  bubbleMeta: { color: theme.textDim, fontSize: 10, marginTop: 6 },
  linkRow: { alignItems: "center", paddingVertical: 4 },
  link: { color: theme.accent, fontSize: 13, padding: 6 },
  inputRow: { flexDirection: "row", padding: theme.spacing, gap: 8, alignItems: "flex-end" },
  input: {
    flex: 1,
    backgroundColor: theme.bgCard,
    color: theme.text,
    borderRadius: theme.radius,
    padding: 12,
    maxHeight: 120,
  },
  sendBtn: {
    backgroundColor: theme.accent,
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
  },
  sendBtnBusy: { opacity: 0.6 },
  sendText: { color: theme.bg, fontSize: 18 },
  listPad: { padding: theme.spacing, gap: 10, paddingBottom: 32 },
  card: { backgroundColor: theme.bgCard, borderRadius: theme.radius, padding: 14, gap: 8 },
  cardActive: { borderColor: theme.accent, borderWidth: 1 },
  cardTitle: { color: theme.text, fontWeight: "700", fontSize: 15 },
  cardBody: { color: theme.textDim, lineHeight: 19 },
  field: {
    backgroundColor: theme.bgElevated,
    color: theme.text,
    borderRadius: 10,
    padding: 10,
  },
  fieldMultiline: { minHeight: 70, textAlignVertical: "top" },
  primaryBtn: { backgroundColor: theme.accent, borderRadius: 12, padding: 12, alignItems: "center" },
  primaryBtnText: { color: theme.bg, fontWeight: "700" },
  footNote: { color: theme.textDim, fontSize: 12, lineHeight: 18 },
  memActions: { flexDirection: "row", gap: 10, padding: theme.spacing },
  ghostBtn: { flex: 1, borderRadius: 12, padding: 12, alignItems: "center", backgroundColor: theme.bgElevated },
  ghostDanger: { backgroundColor: "#3B1D22" },
  ghostBtnText: { color: theme.text },
  rowBetween: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  tabBar: { flexDirection: "row", borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: "#223", paddingBottom: Platform.OS === "ios" ? 20 : 8 },
  tabItem: { flex: 1, alignItems: "center", paddingVertical: 8, gap: 2 },
  tabIcon: { fontSize: 18, color: theme.textDim },
  tabIconActive: { color: theme.accent },
  tabLabel: { fontSize: 10, color: theme.textDim },
  tabLabelActive: { color: theme.accent },
  modalRoot: { flex: 1, backgroundColor: theme.bg, padding: theme.spacing, paddingTop: 64, gap: 12 },
  exportBox: { flex: 1, textAlignVertical: "top" },
});
