// Stub di moduli nativi: permettono il typecheck senza node_modules completo.
declare module "@react-native-async-storage/async-storage" {
  export const getItem: (key: string) => Promise<string | null>;
  export const setItem: (key: string, value: string) => Promise<void>;
  export const removeItem: (key: string) => Promise<void>;
}
declare module "react-native" {
  export const ActivityIndicator: any;
  export const Alert: { alert: (...args: any[]) => void };
  export const FlatList: any;
  export const KeyboardAvoidingView: any;
  export const Modal: any;
  export const Platform: { OS: "ios" | "android"; select: <T>(o: { ios: T; android: T }) => T };
  export const Pressable: any;
  export const ScrollView: any;
  export const StyleSheet: {
    create: (styles: any) => any;
    hairlineWidth: number;
  };
  export const Switch: any;
  export const Text: any;
  export const TextInput: any;
  export const View: any;
  export function registerRootComponent(Component: any): void;
}
declare module "expo-speech" {
  export function speak(text: string, options?: Record<string, unknown>): void;
  export function stop(): void;
}
